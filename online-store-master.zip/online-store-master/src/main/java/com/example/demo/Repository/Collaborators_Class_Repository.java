package com.example.demo.Repository;

import com.example.demo.Entity.Collaborators_Class;
import org.springframework.data.repository.CrudRepository;

public interface Collaborators_Class_Repository extends CrudRepository<Collaborators_Class,String> {
}
