package com.example.demo.Repository;


import com.example.demo.Entity.Statistics;
import org.springframework.data.repository.CrudRepository;

public interface Statistics_Repository extends CrudRepository<Statistics,String> {
}
