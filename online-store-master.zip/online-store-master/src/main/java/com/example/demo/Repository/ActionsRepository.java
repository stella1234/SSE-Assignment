package com.example.demo.Repository;

import com.example.demo.Entity.Actions;
import com.example.demo.Entity.Brand;
import org.springframework.data.repository.CrudRepository;

public interface ActionsRepository extends CrudRepository<Actions,Integer> {
}
