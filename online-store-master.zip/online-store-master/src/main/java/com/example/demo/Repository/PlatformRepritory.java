package com.example.demo.Repository;

import com.example.demo.Entity.Platform;
import org.springframework.data.repository.CrudRepository;

public interface PlatformRepritory extends CrudRepository<Platform,String> {
}
